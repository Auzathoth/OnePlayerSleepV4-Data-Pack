# One Player Sleep Data Pack for Minecraft 1.15 to 1.20++

Thank you for choosing my data pack! Many years of testing in several servers and addressing all the problems has made this a really solid pack.

To better serve the community I've  added some fool-proofing needed for servers with odd settings (like having the weather cycle off).

## Features

This One Player Sleep Data Pack allows a player to skip the night on a Multiplayer Server.

Some of the features include:

- Plug and Play. Drop the zip file in the datapacks folder of your world everything will be installed automatically
- Weather Control. A common problem in multiplayer servers is that the weather goes crazy after skipping the night too many times, this Data Pack solves it.
- Waking up system. Any player can wake up sleeping players to stop them from skiping the night, just click on the sleeping announcement.
- Random sleeping announcements. A series of messages displayed at random when someone sleeps.
- Random wake up messages. A series of messages when a player is woken up by somebody.
- Players can stop storms if they go to sleep when is daytime.

## Version 4.0 Changelog

- No longer using the /data command or looking for NBT
- Most checks are now done via predicates improving the data pack performance
- This version is no longer compatible with older versions of Minecraft
- No personal player scores are stored anymore
- No time query is performed anymore, also storing current time in a scoreboard is not needed anymore.
- Removed references to old data packs and scoreboards
- Updated metadata for the new data pack browser introduced in Minecraft 1.16

## Version 4.1 Changelog

- Fixed predicate to clear rain after sleeping, it was only clearing storms

## Version 4.2 Changelog

- Added more sleeping messages! There is a total of 22 now. Thanks to DrathMorg for the suggestions!
- Changed text colors to use the hex colors introduced in 1.16
- Updated pack image to reflect the version

## Version 4.3 Changelog

- Updated for Minecraft 1.20 (a real test of time!). Thanks to Auzathoth for a very helpful fix for this version
- Updated pack version and image
- Modified the release folder in GitHub to better reflect compatibility with Minecraft versions

## Version 4.4 Changelog

- Updated for Minecraft 1.21 - 1.21.4
- functions are now stored in function

## Version 4.5 Changelog

- Update for Minecraft 1.21.5 - 1.21.10
- clickEvent -> click_event
- hoverEvent -> hover_event
- value is some elements is now specifically command or url

## Version 4.6 Changelog

- Update for MC 1.21.11
- doWeatherCycle is now advance_weather

## Version 4.7 Changelog

- Update for MC 26.1 - 26.1.2
- time features need to specify which dimension 

## Version 4.8 Changelog

- Update for MC 26.2
- "type" in predicates is now "minecraft:entity_type"

## More resources

A download list of [Minecraft 1.16 Data Packs][dplist] where this is included
To see this in action you can visit [my website][mcweb].

Videos from newer to older:

- OPS for Minecraft 1.16+ [video][yt4.2] (v4.2)
- OPS for Minecraft 1.14/1.15 [video][yt3.0] (v3.0)
- Weather changes [video][yt2.4] (v2.4).
- Messaging update [video][yt2.2] (v2.2).
- First data pack version [video][yt2.1].

   [dplist]: <https://www.madcatgaming.com/data-packs-minecraft-1-16/>
   [mcweb]: <https://www.madcatgaming.com/one-player-sleep-data-pack/>
   [yt4.2]: <https://youtu.be/3yxHWIDNDuM>
   [yt3.0]: <https://youtu.be/84iws5sjINY>
   [yt2.4]: <https://youtu.be/dg8eUG3aYoo>
   [yt2.2]: <https://youtu.be/CbQggVOskSs>
   [yt2.1]: <https://youtu.be/b_RaFutGFMI>
